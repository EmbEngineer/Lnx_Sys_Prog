#ifndef NOF 
#define NOF 6
#endif

int init();
void* exitFunc(void*);
void* (*fptr[NOF])(void*);
